<div class="col-xl-12 col-md-12">
    <div class="card">
        <div class="card-header">
            <h5>Data Donasi Campaign 2021</h5>
        </div>
        <div class="card-body">
            <div class="chart-area">
                <canvas id="chartarea_campaign"></canvas>
            </div>
        </div>
    </div>
</div>