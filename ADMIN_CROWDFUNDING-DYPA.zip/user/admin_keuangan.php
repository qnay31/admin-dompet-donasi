<script>
document.location.href = '../dashboard.php';
</script>